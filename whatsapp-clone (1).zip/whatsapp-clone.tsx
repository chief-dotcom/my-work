"use client"

import type React from "react"

import { useEffect, useState, useRef, useCallback, useMemo } from "react"
import { Search, Phone, Video, Mic, Send, Info } from "lucide-react"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useSocketStore, type MessageType } from "@/lib/socket"
import { FileAttachmentMenu } from "@/components/file-attachment-menu"
import { FileMessage } from "@/components/file-message"
import { UploadProgress } from "@/components/upload-progress"
import { CreateGroupModal } from "@/components/create-group-modal"
import { GroupSettingsModal } from "@/components/group-settings-modal"
import { EmojiPicker } from "@/components/emoji-picker"
import { QuickEmojiBar } from "@/components/quick-emoji-bar"
import { VoiceRecorder } from "@/components/voice-recorder"
import { StatusList } from "@/components/status-list"
import { CallModal } from "@/components/call-modal"
import { CallHistory } from "@/components/call-history"
import { useCallStore } from "@/lib/call-store"
import { BackButton } from "@/components/back-button"
import { useNavigationStore, useBackButton } from "@/hooks/use-navigation"
import { BottomNavigation } from "@/components/bottom-navigation"
import { HamburgerMenu } from "@/components/hamburger-menu"
import { AddContactModal } from "@/components/add-contact-modal"
import { ContactListModal } from "@/components/contact-list-modal"
import { AuthModal } from "@/components/auth/auth-modal"
import { ProfileModal } from "@/components/profile/profile-modal"
import { useAuthStore } from "@/lib/auth-store"

export default function WhatsAppClone() {
  const [message, setMessage] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messageEndRef = useRef<HTMLDivElement>(null)
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const [isRecordingVoice, setIsRecordingVoice] = useState(false)
  const [activeTab, setActiveTab] = useState<"chats" | "status" | "calls">("chats")

  const [showCreateGroup, setShowCreateGroup] = useState(false)
  const [showGroupSettings, setShowGroupSettings] = useState(false)
  const [showCallModal, setShowCallModal] = useState(false)
  const [showAddContact, setShowAddContact] = useState(false)
  const [showContactList, setShowContactList] = useState(false)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [showProfileModal, setShowProfileModal] = useState(false)

  const { pushView, setCurrentView } = useNavigationStore()
  const { user, isAuthenticated } = useAuthStore()

  const {
    connect,
    disconnect,
    connected,
    chats,
    messages,
    activeChat,
    typingUsers,
    uploadingFiles,
    sendMessage,
    sendFileMessage,
    sendVoiceMessage,
    setActiveChat,
    setTyping,
    markAsRead,
  } = useSocketStore()

  const { currentCall, startCall, receiveCall } = useCallStore()

  // Show auth modal if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      setShowAuthModal(true)
    } else {
      setShowAuthModal(false)
    }
  }, [isAuthenticated])

  // Handle global back button for main navigation
  useBackButton(() => {
    if (activeChat) {
      setActiveChat(null)
      return true
    }
    return false
  })

  // Memoize computed values to prevent unnecessary re-renders
  const selectedChat = useMemo(() => chats.find((chat) => chat.id === activeChat), [chats, activeChat])
  const currentMessages = useMemo(() => (activeChat ? messages[activeChat] || [] : []), [messages, activeChat])
  const isOtherUserTyping = useMemo(() => (activeChat ? typingUsers[activeChat] : false), [typingUsers, activeChat])

  // Memoize connection functions to prevent re-creation on every render
  const handleConnect = useCallback(() => {
    if (!connected && isAuthenticated) {
      connect()
    }
  }, [connect, connected, isAuthenticated])

  const handleDisconnect = useCallback(() => {
    disconnect()
  }, [disconnect])

  // Connect to WebSocket on component mount (only if authenticated)
  useEffect(() => {
    if (isAuthenticated) {
      handleConnect()
    }
    return handleDisconnect
  }, [handleConnect, handleDisconnect, isAuthenticated])

  // Show call modal when there's an active call
  useEffect(() => {
    if (currentCall) {
      setShowCallModal(true)
    }
  }, [currentCall])

  // Update navigation state when activeChat changes
  useEffect(() => {
    if (activeChat) {
      pushView(`chat-${activeChat}`)
    } else {
      setCurrentView(activeTab)
    }
  }, [activeChat, activeTab, pushView, setCurrentView])

  // Scroll to bottom when messages change (throttled)
  useEffect(() => {
    if (activeTab === "chats" && currentMessages.length > 0) {
      const timeoutId = setTimeout(() => {
        messageEndRef.current?.scrollIntoView({ behavior: "smooth" })
      }, 100)

      return () => clearTimeout(timeoutId)
    }
  }, [currentMessages.length, activeTab])

  // Mark messages as read when chat is active (throttled)
  useEffect(() => {
    if (activeChat && activeTab === "chats") {
      const timeoutId = setTimeout(() => {
        markAsRead(activeChat)
      }, 100)

      return () => clearTimeout(timeoutId)
    }
  }, [activeChat, markAsRead, activeTab])

  // Handle typing indicator with proper cleanup
  const handleTyping = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const newMessage = e.target.value
      setMessage(newMessage)

      if (!isTyping && newMessage && activeChat) {
        setIsTyping(true)
        setTyping(activeChat, true)
      }

      // Clear existing timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current)
      }

      // Set new timeout
      typingTimeoutRef.current = setTimeout(() => {
        setIsTyping(false)
        if (activeChat) {
          setTyping(activeChat, false)
        }
      }, 1000)
    },
    [isTyping, activeChat, setTyping],
  )

  const handleSendMessage = useCallback(() => {
    if (message.trim() && activeChat) {
      sendMessage(activeChat, message.trim())
      setMessage("")
      setIsTyping(false)
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current)
      }
      setTyping(activeChat, false)
    }
  }, [message, activeChat, sendMessage, setTyping])

  const handleFileSelect = useCallback(
    (file: File, type: MessageType) => {
      if (activeChat) {
        sendFileMessage(activeChat, file, type)
      }
    },
    [activeChat, sendFileMessage],
  )

  const formatMessageTime = useCallback((time: string) => {
    return time
  }, [])

  const connectionStatus = useMemo(() => {
    if (!isAuthenticated) {
      return <span className="text-xs text-gray-500">Not authenticated</span>
    }
    return connected ? (
      <span className="text-xs text-green-500">Connected</span>
    ) : (
      <span className="text-xs text-red-500">Connecting...</span>
    )
  }, [connected, isAuthenticated])

  const handleVoiceStart = useCallback(() => {
    setIsRecordingVoice(true)
  }, [])

  const handleVoiceSend = useCallback(
    (audioBlob: Blob, duration: number) => {
      if (activeChat) {
        sendVoiceMessage(activeChat, audioBlob, duration)
      }
      setIsRecordingVoice(false)
    },
    [activeChat, sendVoiceMessage],
  )

  const handleVoiceCancel = useCallback(() => {
    setIsRecordingVoice(false)
  }, [])

  // Handle tab switching
  const handleTabSwitch = useCallback(
    (tab: "chats" | "status" | "calls") => {
      setActiveTab(tab)
      if (tab === "status" || tab === "calls") {
        setActiveChat(null)
      }
      setCurrentView(tab)
    },
    [setActiveChat, setCurrentView],
  )

  const handleChatSelect = useCallback(
    (chatId: string) => {
      setActiveChat(chatId)
      pushView(`chat-${chatId}`)
    },
    [setActiveChat, pushView],
  )

  // Don't render main app if not authenticated
  if (!isAuthenticated) {
    return (
      <>
        <div className="flex h-screen bg-gray-100 dark:bg-gray-900 items-center justify-center">
          <div className="text-center">
            <div className="w-32 h-32 mx-auto mb-8 bg-[#00a884] rounded-full flex items-center justify-center">
              <div className="text-6xl text-white">💬</div>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Welcome to WhatsApp</h1>
            <p className="text-gray-600 dark:text-gray-400 mb-8 max-w-md">
              Connect with friends and family through secure messaging, voice calls, and video calls.
            </p>
            <Button
              onClick={() => setShowAuthModal(true)}
              className="bg-[#00a884] hover:bg-[#008f72] text-white px-8 py-3 text-lg"
            >
              Get Started
            </Button>
          </div>
        </div>
        <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
      </>
    )
  }

  const renderSidebar = () => {
    if (activeTab === "status") {
      return <StatusList />
    }

    if (activeTab === "calls") {
      return <CallHistory />
    }

    // Chats tab
    return (
      <div className="w-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
        {/* Header */}
        <div className="bg-[#00a884] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <AvatarImage src={user?.avatar || "/placeholder.svg"} alt="Profile" />
              <AvatarFallback>
                {user?.name
                  ?.split(" ")
                  .map((n) => n[0])
                  .join("") || "U"}
              </AvatarFallback>
            </Avatar>
            <div>
              <span className="font-medium">WhatsApp</span>
              <div className="text-xs">{connectionStatus}</div>
            </div>
          </div>
          <HamburgerMenu
            onNewGroup={() => setShowCreateGroup(true)}
            onAddContact={() => setShowAddContact(true)}
            onViewContacts={() => setShowContactList(true)}
            onViewProfile={() => setShowProfileModal(true)}
          />
        </div>

        {/* Search */}
        <div className="p-3 bg-gray-50 dark:bg-gray-700 border-b dark:border-gray-600">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search or start new chat"
              className="pl-10 bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-600"
            />
          </div>
        </div>

        {/* Chat List */}
        <ScrollArea className="flex-1">
          {chats.map((chat) => (
            <div
              key={chat.id}
              className={`flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer border-b border-gray-100 dark:border-gray-700 ${
                activeChat === chat.id ? "bg-gray-100 dark:bg-gray-700" : ""
              }`}
              onClick={() => handleChatSelect(chat.id)}
            >
              <div className="relative">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={chat.avatar || "/placeholder.svg"} alt={chat.name} />
                  <AvatarFallback>
                    {chat.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                {chat.online && (
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white dark:border-gray-800"></div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-gray-900 dark:text-white truncate">{chat.name}</h3>
                  <span className="text-xs text-gray-500 dark:text-gray-400">{chat.time}</span>
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-600 dark:text-gray-300 truncate">{chat.lastMessage}</p>
                  {chat.unread && chat.unread > 0 && (
                    <span className="bg-[#00a884] text-white text-xs rounded-full px-2 py-1 min-w-[20px] text-center">
                      {chat.unread}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </ScrollArea>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900 flex-col">
      {/* Main Content Area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar - Hidden on mobile when chat is active */}
        <div className={`${activeChat ? "hidden md:flex" : "flex"} w-full md:w-1/3`}>{renderSidebar()}</div>

        {/* Main Chat Area */}
        <div className={`${activeChat ? "flex" : "hidden md:flex"} flex-1 flex-col`}>
          {selectedChat && activeTab === "chats" ? (
            <>
              {/* Chat Header */}
              <div className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <BackButton
                    onBack={() => setActiveChat(null)}
                    className="text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 md:hidden"
                  />
                  <div className="relative">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={selectedChat.avatar || "/placeholder.svg"} alt={selectedChat.name} />
                      <AvatarFallback>
                        {selectedChat.isGroup ? (
                          <div className="w-5 h-5 text-gray-500">👥</div>
                        ) : (
                          selectedChat.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                        )}
                      </AvatarFallback>
                    </Avatar>
                    {!selectedChat.isGroup && selectedChat.online && (
                      <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white dark:border-gray-800"></div>
                    )}
                  </div>
                  <div
                    className="flex-1 cursor-pointer"
                    onClick={() => selectedChat.isGroup && setShowGroupSettings(true)}
                  >
                    <h2 className="font-medium text-gray-900 dark:text-white">{selectedChat.name}</h2>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {selectedChat.isGroup ? (
                        `${selectedChat.participants?.length || 0} members`
                      ) : isOtherUserTyping ? (
                        <span className="text-green-600">typing...</span>
                      ) : selectedChat.online ? (
                        "online"
                      ) : (
                        "last seen recently"
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() =>
                      selectedChat &&
                      startCall(
                        {
                          id: selectedChat.id,
                          name: selectedChat.name,
                          avatar: selectedChat.avatar || "/placeholder.svg",
                          online: selectedChat.online || false,
                        },
                        "video",
                      )
                    }
                  >
                    <Video className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() =>
                      selectedChat &&
                      startCall(
                        {
                          id: selectedChat.id,
                          name: selectedChat.name,
                          avatar: selectedChat.avatar || "/placeholder.svg",
                          online: selectedChat.online || false,
                        },
                        "voice",
                      )
                    }
                  >
                    <Phone className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </Button>
                  {selectedChat.isGroup && (
                    <Button variant="ghost" size="icon" onClick={() => setShowGroupSettings(true)}>
                      <Info className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                    </Button>
                  )}
                </div>
              </div>

              {/* Messages */}
              <ScrollArea
                className="flex-1 p-4 bg-[#efeae2] dark:bg-gray-900"
                style={{
                  backgroundImage:
                    "url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iYSIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgd2lkdGg9IjIwIiBoZWlnaHQ9IjIwIiBwYXR0ZXJuVHJhbnNmb3JtPSJyb3RhdGUoNDUpIj48cmVjdCB3aWR0aD0iMSIgaGVpZ2h0PSIxIiBmaWxsPSIjZjBmMGYwIiBmaWxsLW9wYWNpdHk9Ii4xIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2EpIi8+PC9zdmc+')",
                }}
              >
                {/* Upload Progress Indicators */}
                {Object.entries(uploadingFiles).length > 0 && (
                  <div className="sticky top-0 z-10 px-4 py-2">
                    {Object.entries(uploadingFiles).map(([id, { progress, name }]) => (
                      <UploadProgress key={id} fileName={name} progress={progress} />
                    ))}
                  </div>
                )}

                <div className="space-y-4">
                  {currentMessages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.sent ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          msg.sent
                            ? "bg-[#d9fdd3] dark:bg-green-800 text-gray-800 dark:text-white"
                            : "bg-white dark:bg-gray-700 text-gray-800 dark:text-white"
                        } ${msg.pending ? "opacity-70" : ""}`}
                      >
                        {/* Show sender name for group messages */}
                        {selectedChat?.isGroup && !msg.sent && msg.senderId !== "system" && (
                          <div className="text-xs font-medium text-[#00a884] mb-1">
                            {selectedChat.participants?.find((p) => p.id === msg.senderId)?.name || "Unknown"}
                          </div>
                        )}

                        {msg.type === "text" && <p className="text-sm">{msg.text}</p>}

                        {msg.type !== "text" && msg.file && <FileMessage file={msg.file} type={msg.type} />}

                        <div className={`flex items-center gap-1 mt-1 ${msg.sent ? "justify-end" : "justify-start"}`}>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {formatMessageTime(msg.time)}
                          </span>
                          {msg.sent && (
                            <div className="flex">
                              <div
                                className={`w-4 h-4 ${msg.read ? "text-blue-500" : msg.delivered ? "text-gray-400" : "text-gray-300"}`}
                              >
                                <svg viewBox="0 0 16 15" className="w-full h-full fill-current">
                                  <path d="M15.01 3.316l-.478-.372a.365.365 0 0 0-.51.063L8.666 9.879a.32.32 0 0 1-.484.033l-.358-.325a.319.319 0 0 0-.484.032l-.378.483a.418.418 0 0 0 .036.541l1.32 1.266c.143.14.361.125.484-.033l6.272-8.048a.366.366 0 0 0-.063-.51zm-4.1 0l-.478-.372a.365.365 0 0 0-.51.063L4.566 9.879a.32.32 0 0 1-.484.033L1.891 7.769a.319.319 0 0 0-.484.032l-.378.483a.418.418 0 0 0 .036.541l3.61 3.463c.143.14.361.125.484-.033l6.272-8.048a.366.366 0 0 0-.063-.51z" />
                                </svg>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {isOtherUserTyping && (
                    <div className="flex justify-start">
                      <div className="bg-white dark:bg-gray-700 text-gray-800 dark:text-white px-4 py-2 rounded-lg">
                        <div className="flex space-x-1">
                          <div
                            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                            style={{ animationDelay: "0ms" }}
                          ></div>
                          <div
                            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                            style={{ animationDelay: "200ms" }}
                          ></div>
                          <div
                            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                            style={{ animationDelay: "400ms" }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messageEndRef} />
                </div>
              </ScrollArea>

              {/* Message Input */}
              <div className="bg-gray-50 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-4">
                {/* Quick Emoji Bar */}
                <QuickEmojiBar onEmojiSelect={(emoji) => setMessage((prev) => prev + emoji)} />

                {isRecordingVoice ? (
                  <VoiceRecorder onSendVoice={handleVoiceSend} onCancel={handleVoiceCancel} />
                ) : (
                  <div className="flex items-center gap-2">
                    <EmojiPicker onEmojiSelect={(emoji) => setMessage((prev) => prev + emoji)} />
                    <FileAttachmentMenu onFileSelect={handleFileSelect} />
                    <div className="flex-1 relative">
                      <Input
                        placeholder="Type a message"
                        value={message}
                        onChange={handleTyping}
                        onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                        className="pr-12 bg-white dark:bg-gray-700 border-gray-200 dark:border-gray-600"
                        disabled={!connected || !activeChat}
                      />
                    </div>
                    {message.trim() ? (
                      <Button
                        onClick={handleSendMessage}
                        className="bg-[#00a884] hover:bg-[#008f72] text-white rounded-full w-10 h-10 p-0"
                        disabled={!connected || !activeChat}
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    ) : (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-gray-600 dark:text-gray-400"
                        onClick={handleVoiceStart}
                        disabled={!connected || !activeChat}
                      >
                        <Mic className="w-5 h-5" />
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </>
          ) : (
            /* Welcome Screen */
            <div className="flex-1 flex items-center justify-center bg-gray-50 dark:bg-gray-800">
              <div className="text-center">
                <div className="w-64 h-64 mx-auto mb-8 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center">
                  <div className="text-6xl text-gray-400">
                    {activeTab === "status" ? "📸" : activeTab === "calls" ? "📞" : "💬"}
                  </div>
                </div>
                <h2 className="text-2xl font-light text-gray-600 dark:text-gray-300 mb-2">
                  {activeTab === "status" ? "Status Updates" : activeTab === "calls" ? "Calls" : "WhatsApp Web"}
                </h2>
                <p className="text-gray-500 dark:text-gray-400 max-w-md">
                  {activeTab === "status"
                    ? "Share photos, videos, and text updates that disappear after 24 hours. Click on a contact's status to view their updates."
                    : activeTab === "calls"
                      ? "Make voice and video calls to your contacts. Your call history will appear here."
                      : "Send and receive messages without keeping your phone online. Use WhatsApp on up to 4 linked devices and 1 phone at the same time."}
                </p>
                <div className="mt-4 text-sm text-green-600">
                  {connected ? "Connected to WebSocket server" : "Connecting to WebSocket server..."}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab={activeTab} onTabChange={handleTabSwitch} />

      {/* Modals */}
      <CreateGroupModal isOpen={showCreateGroup} onClose={() => setShowCreateGroup(false)} />
      <GroupSettingsModal isOpen={showGroupSettings} onClose={() => setShowGroupSettings(false)} group={selectedChat} />
      <CallModal isOpen={showCallModal} onClose={() => setShowCallModal(false)} />
      <AddContactModal isOpen={showAddContact} onClose={() => setShowAddContact(false)} />
      <ContactListModal isOpen={showContactList} onClose={() => setShowContactList(false)} />
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
      <ProfileModal isOpen={showProfileModal} onClose={() => setShowProfileModal(false)} />
    </div>
  )
}
