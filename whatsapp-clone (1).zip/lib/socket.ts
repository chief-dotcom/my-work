import { create } from "zustand"

export type MessageType = "text" | "image" | "video" | "audio" | "document"

export interface Message {
  id: string
  text?: string
  file?: {
    name: string
    size: number
    type: string
    url: string
  }
  type: MessageType
  time: string
  sent: boolean
  delivered?: boolean
  read?: boolean
  pending?: boolean
  senderId?: string
}

export interface Chat {
  id: string
  name: string
  avatar?: string
  lastMessage: string
  time: string
  unread?: number
  online?: boolean
  isGroup?: boolean
  participants?: Array<{
    id: string
    name: string
    avatar?: string
    role?: "admin" | "member"
  }>
  isPinned?: boolean
}

export interface Contact {
  id: string
  name: string
  phone: string
  avatar?: string
  online?: boolean
  lastSeen?: string
}

export interface UploadingFile {
  name: string
  progress: number
}

interface SocketState {
  connected: boolean
  chats: Chat[]
  messages: Record<string, Message[]>
  activeChat: string | null
  typingUsers: Record<string, boolean>
  uploadingFiles: Record<string, UploadingFile>
  contacts: Contact[]

  // Actions
  connect: () => void
  disconnect: () => void
  sendMessage: (chatId: string, text: string) => void
  sendFileMessage: (chatId: string, file: File, type: MessageType) => void
  sendVoiceMessage: (chatId: string, audioBlob: Blob, duration: number) => void
  setActiveChat: (chatId: string | null) => void
  setTyping: (chatId: string, isTyping: boolean) => void
  markAsRead: (chatId: string) => void
  addContact: (contact: Omit<Contact, "id">) => Promise<{ success: boolean; message: string }>
  searchContacts: (query: string) => Contact[]
  createGroup: (
    name: string,
    participants: string[],
  ) => Promise<{ success: boolean; groupId?: string; message: string }>
  pinChat: (chatId: string) => void
  unpinChat: (chatId: string) => void
}

// Mock data
const mockChats: Chat[] = [
  {
    id: "1",
    name: "John Doe",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Hey, how are you doing?",
    time: "10:30 AM",
    unread: 2,
    online: true,
  },
  {
    id: "2",
    name: "Jane Smith",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "See you tomorrow!",
    time: "9:15 AM",
    online: false,
  },
  {
    id: "3",
    name: "Family Group",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Mom: Don't forget dinner tonight",
    time: "8:45 AM",
    unread: 5,
    isGroup: true,
    participants: [
      { id: "mom", name: "Mom", role: "admin" },
      { id: "dad", name: "Dad", role: "member" },
      { id: "sister", name: "Sister", role: "member" },
    ],
    isPinned: true,
  },
  {
    id: "4",
    name: "Work Team",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Alice: Meeting at 3 PM",
    time: "Yesterday",
    isGroup: true,
    participants: [
      { id: "alice", name: "Alice", role: "admin" },
      { id: "bob", name: "Bob", role: "member" },
      { id: "charlie", name: "Charlie", role: "member" },
    ],
  },
]

const mockMessages: Record<string, Message[]> = {
  "1": [
    {
      id: "1",
      text: "Hey there! How are you doing?",
      type: "text",
      time: "10:25 AM",
      sent: false,
      delivered: true,
      read: true,
      senderId: "1",
    },
    {
      id: "2",
      text: "I'm doing great, thanks for asking!",
      type: "text",
      time: "10:26 AM",
      sent: true,
      delivered: true,
      read: true,
    },
    {
      id: "3",
      text: "What about you? How's work going?",
      type: "text",
      time: "10:26 AM",
      sent: true,
      delivered: true,
      read: false,
    },
    {
      id: "4",
      text: "Work is busy but good! Just finished a big project.",
      type: "text",
      time: "10:30 AM",
      sent: false,
      delivered: true,
      read: false,
      senderId: "1",
    },
  ],
  "2": [
    {
      id: "1",
      text: "Don't forget about our meeting tomorrow!",
      type: "text",
      time: "9:10 AM",
      sent: false,
      delivered: true,
      read: true,
      senderId: "2",
    },
    {
      id: "2",
      text: "Of course! I'll be there at 2 PM sharp.",
      type: "text",
      time: "9:12 AM",
      sent: true,
      delivered: true,
      read: true,
    },
    {
      id: "3",
      text: "Perfect! See you tomorrow 👍",
      type: "text",
      time: "9:15 AM",
      sent: false,
      delivered: true,
      read: false,
      senderId: "2",
    },
  ],
  "3": [
    {
      id: "1",
      text: "Hey everyone! Don't forget about dinner tonight at 7 PM",
      type: "text",
      time: "8:30 AM",
      sent: false,
      delivered: true,
      read: true,
      senderId: "mom",
    },
    {
      id: "2",
      text: "I'll be there! Should I bring anything?",
      type: "text",
      time: "8:35 AM",
      sent: true,
      delivered: true,
      read: true,
    },
    {
      id: "3",
      text: "Just bring yourself! I've got everything covered 😊",
      type: "text",
      time: "8:40 AM",
      sent: false,
      delivered: true,
      read: true,
      senderId: "mom",
    },
    {
      id: "4",
      text: "Can't wait! Your cooking is the best Mom ❤️",
      type: "text",
      time: "8:45 AM",
      sent: false,
      delivered: true,
      read: false,
      senderId: "sister",
    },
  ],
}

const mockContacts: Contact[] = [
  {
    id: "1",
    name: "John Doe",
    phone: "+1 (555) 123-4567",
    avatar: "/placeholder.svg?height=40&width=40",
    online: true,
  },
  {
    id: "2",
    name: "Jane Smith",
    phone: "+1 (555) 234-5678",
    avatar: "/placeholder.svg?height=40&width=40",
    online: false,
    lastSeen: "2 hours ago",
  },
  {
    id: "3",
    name: "Alice Johnson",
    phone: "+1 (555) 345-6789",
    avatar: "/placeholder.svg?height=40&width=40",
    online: true,
  },
  {
    id: "4",
    name: "Bob Wilson",
    phone: "+1 (555) 456-7890",
    avatar: "/placeholder.svg?height=40&width=40",
    online: false,
    lastSeen: "1 day ago",
  },
]

export const useSocketStore = create<SocketState>((set, get) => ({
  connected: false,
  chats: mockChats,
  messages: mockMessages,
  activeChat: null,
  typingUsers: {},
  uploadingFiles: {},
  contacts: mockContacts,

  connect: () => {
    // Simulate connection
    setTimeout(() => {
      set({ connected: true })
    }, 1000)
  },

  disconnect: () => {
    set({ connected: false })
  },

  sendMessage: (chatId: string, text: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      type: "text",
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sent: true,
      pending: true,
    }

    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: [...(state.messages[chatId] || []), newMessage],
      },
      chats: state.chats.map((chat) =>
        chat.id === chatId ? { ...chat, lastMessage: text, time: newMessage.time, unread: 0 } : chat,
      ),
    }))

    // Simulate message delivery
    setTimeout(() => {
      set((state) => ({
        messages: {
          ...state.messages,
          [chatId]:
            state.messages[chatId]?.map((msg) =>
              msg.id === newMessage.id ? { ...msg, pending: false, delivered: true } : msg,
            ) || [],
        },
      }))
    }, 1000)
  },

  sendFileMessage: (chatId: string, file: File, type: MessageType) => {
    const fileId = Date.now().toString()

    // Add to uploading files
    set((state) => ({
      uploadingFiles: {
        ...state.uploadingFiles,
        [fileId]: { name: file.name, progress: 0 },
      },
    }))

    // Simulate upload progress
    const interval = setInterval(() => {
      set((state) => {
        const currentProgress = state.uploadingFiles[fileId]?.progress || 0
        const newProgress = Math.min(currentProgress + 10, 100)

        if (newProgress >= 100) {
          clearInterval(interval)

          // Remove from uploading and add as message
          const { [fileId]: removed, ...remainingUploads } = state.uploadingFiles

          const newMessage: Message = {
            id: fileId,
            type,
            file: {
              name: file.name,
              size: file.size,
              type: file.type,
              url: URL.createObjectURL(file),
            },
            time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            sent: true,
            delivered: true,
          }

          return {
            uploadingFiles: remainingUploads,
            messages: {
              ...state.messages,
              [chatId]: [...(state.messages[chatId] || []), newMessage],
            },
            chats: state.chats.map((chat) =>
              chat.id === chatId ? { ...chat, lastMessage: `📎 ${file.name}`, time: newMessage.time, unread: 0 } : chat,
            ),
          }
        }

        return {
          uploadingFiles: {
            ...state.uploadingFiles,
            [fileId]: { name: file.name, progress: newProgress },
          },
        }
      })
    }, 200)
  },

  sendVoiceMessage: (chatId: string, audioBlob: Blob, duration: number) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      type: "audio",
      file: {
        name: `Voice message ${duration}s`,
        size: audioBlob.size,
        type: audioBlob.type,
        url: URL.createObjectURL(audioBlob),
      },
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sent: true,
      delivered: true,
    }

    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: [...(state.messages[chatId] || []), newMessage],
      },
      chats: state.chats.map((chat) =>
        chat.id === chatId ? { ...chat, lastMessage: "🎤 Voice message", time: newMessage.time, unread: 0 } : chat,
      ),
    }))
  },

  setActiveChat: (chatId: string | null) => {
    set({ activeChat: chatId })
  },

  setTyping: (chatId: string, isTyping: boolean) => {
    set((state) => ({
      typingUsers: {
        ...state.typingUsers,
        [chatId]: isTyping,
      },
    }))
  },

  markAsRead: (chatId: string) => {
    set((state) => ({
      chats: state.chats.map((chat) => (chat.id === chatId ? { ...chat, unread: 0 } : chat)),
      messages: {
        ...state.messages,
        [chatId]: state.messages[chatId]?.map((msg) => ({ ...msg, read: true })) || [],
      },
    }))
  },

  addContact: async (contact: Omit<Contact, "id">) => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const newContact: Contact = {
      ...contact,
      id: Date.now().toString(),
      online: Math.random() > 0.5,
    }

    set((state) => ({
      contacts: [...state.contacts, newContact],
    }))

    return { success: true, message: "Contact added successfully!" }
  },

  searchContacts: (query: string) => {
    const { contacts } = get()
    if (!query.trim()) return contacts

    return contacts.filter(
      (contact) => contact.name.toLowerCase().includes(query.toLowerCase()) || contact.phone.includes(query),
    )
  },

  createGroup: async (name: string, participants: string[]) => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const { contacts } = get()
    const groupParticipants = participants.map((id) => {
      const contact = contacts.find((c) => c.id === id)
      return {
        id,
        name: contact?.name || "Unknown",
        avatar: contact?.avatar,
        role: "member" as const,
      }
    })

    const newGroup: Chat = {
      id: Date.now().toString(),
      name,
      avatar: "/placeholder.svg?height=40&width=40",
      lastMessage: "Group created",
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isGroup: true,
      participants: [{ id: "current-user", name: "You", role: "admin" }, ...groupParticipants],
    }

    set((state) => ({
      chats: [newGroup, ...state.chats],
    }))

    return { success: true, groupId: newGroup.id, message: "Group created successfully!" }
  },

  pinChat: (chatId: string) => {
    set((state) => ({
      chats: state.chats.map((chat) => (chat.id === chatId ? { ...chat, isPinned: true } : chat)),
    }))
  },

  unpinChat: (chatId: string) => {
    set((state) => ({
      chats: state.chats.map((chat) => (chat.id === chatId ? { ...chat, isPinned: false } : chat)),
    }))
  },
}))
