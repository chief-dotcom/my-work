import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface UserProfile {
  id: string
  name: string
  email: string
  phone: string
  avatar?: string
  bio?: string
  lastSeen?: string
  isOnline: boolean
  createdAt: string
}

export interface AuthState {
  user: UserProfile | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
  register: (userData: RegisterData) => Promise<{ success: boolean; message: string }>
  login: (email: string, password: string) => Promise<{ success: boolean; message: string }>
  logout: () => void
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ success: boolean; message: string }>
  uploadAvatar: (file: File) => Promise<{ success: boolean; avatarUrl?: string; message: string }>
  clearError: () => void
}

export interface RegisterData {
  name: string
  email: string
  phone: string
  password: string
  confirmPassword: string
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      register: async (userData: RegisterData) => {
        set({ isLoading: true, error: null })

        try {
          // Validate input
          if (!userData.name.trim()) {
            throw new Error("Name is required")
          }
          if (!userData.email.trim()) {
            throw new Error("Email is required")
          }
          if (!userData.phone.trim()) {
            throw new Error("Phone number is required")
          }
          if (userData.password.length < 6) {
            throw new Error("Password must be at least 6 characters")
          }
          if (userData.password !== userData.confirmPassword) {
            throw new Error("Passwords do not match")
          }

          // Email validation
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
          if (!emailRegex.test(userData.email)) {
            throw new Error("Please enter a valid email address")
          }

          // Phone validation (basic)
          const phoneRegex = /^\+?[\d\s\-$$$$]{10,}$/
          if (!phoneRegex.test(userData.phone)) {
            throw new Error("Please enter a valid phone number")
          }

          // Simulate API call
          await new Promise((resolve) => setTimeout(resolve, 1500))

          // Check if user already exists (simulate)
          const existingUsers = JSON.parse(localStorage.getItem("registered-users") || "[]")
          const userExists = existingUsers.some((u: any) => u.email === userData.email || u.phone === userData.phone)

          if (userExists) {
            throw new Error("User with this email or phone already exists")
          }

          // Create new user
          const newUser: UserProfile = {
            id: `user-${Date.now()}`,
            name: userData.name.trim(),
            email: userData.email.trim().toLowerCase(),
            phone: userData.phone.trim(),
            bio: "Hey there! I am using WhatsApp.",
            isOnline: true,
            createdAt: new Date().toISOString(),
          }

          // Save to localStorage (simulate database)
          existingUsers.push({ ...newUser, password: userData.password })
          localStorage.setItem("registered-users", JSON.stringify(existingUsers))

          set({
            user: newUser,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          })

          return { success: true, message: "Account created successfully!" }
        } catch (error) {
          const message = error instanceof Error ? error.message : "Registration failed"
          set({ error: message, isLoading: false })
          return { success: false, message }
        }
      },

      login: async (email: string, password: string) => {
        set({ isLoading: true, error: null })

        try {
          if (!email.trim() || !password.trim()) {
            throw new Error("Email and password are required")
          }

          // Simulate API call
          await new Promise((resolve) => setTimeout(resolve, 1000))

          // Check credentials (simulate)
          const existingUsers = JSON.parse(localStorage.getItem("registered-users") || "[]")
          const user = existingUsers.find((u: any) => u.email === email.toLowerCase() && u.password === password)

          if (!user) {
            throw new Error("Invalid email or password")
          }

          // Remove password from user object
          const { password: _, ...userProfile } = user
          const authenticatedUser: UserProfile = {
            ...userProfile,
            isOnline: true,
            lastSeen: new Date().toISOString(),
          }

          set({
            user: authenticatedUser,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          })

          return { success: true, message: "Login successful!" }
        } catch (error) {
          const message = error instanceof Error ? error.message : "Login failed"
          set({ error: message, isLoading: false })
          return { success: false, message }
        }
      },

      logout: () => {
        set({
          user: null,
          isAuthenticated: false,
          error: null,
        })
      },

      updateProfile: async (updates: Partial<UserProfile>) => {
        const currentUser = get().user
        if (!currentUser) {
          return { success: false, message: "No user logged in" }
        }

        set({ isLoading: true, error: null })

        try {
          // Validate updates
          if (updates.name && !updates.name.trim()) {
            throw new Error("Name cannot be empty")
          }
          if (updates.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(updates.email)) {
            throw new Error("Please enter a valid email address")
          }
          if (updates.phone && !/^\+?[\d\s\-$$$$]{10,}$/.test(updates.phone)) {
            throw new Error("Please enter a valid phone number")
          }

          // Simulate API call
          await new Promise((resolve) => setTimeout(resolve, 800))

          const updatedUser: UserProfile = {
            ...currentUser,
            ...updates,
            name: updates.name?.trim() || currentUser.name,
            email: updates.email?.trim().toLowerCase() || currentUser.email,
            phone: updates.phone?.trim() || currentUser.phone,
          }

          // Update in localStorage
          const existingUsers = JSON.parse(localStorage.getItem("registered-users") || "[]")
          const userIndex = existingUsers.findIndex((u: any) => u.id === currentUser.id)
          if (userIndex !== -1) {
            existingUsers[userIndex] = { ...existingUsers[userIndex], ...updatedUser }
            localStorage.setItem("registered-users", JSON.stringify(existingUsers))
          }

          set({
            user: updatedUser,
            isLoading: false,
            error: null,
          })

          return { success: true, message: "Profile updated successfully!" }
        } catch (error) {
          const message = error instanceof Error ? error.message : "Update failed"
          set({ error: message, isLoading: false })
          return { success: false, message }
        }
      },

      uploadAvatar: async (file: File) => {
        set({ isLoading: true, error: null })

        try {
          // Validate file
          if (!file.type.startsWith("image/")) {
            throw new Error("Please select an image file")
          }
          if (file.size > 5 * 1024 * 1024) {
            // 5MB limit
            throw new Error("Image size must be less than 5MB")
          }

          // Simulate upload
          await new Promise((resolve) => setTimeout(resolve, 1500))

          // Create object URL for the avatar
          const avatarUrl = URL.createObjectURL(file)

          const currentUser = get().user
          if (!currentUser) {
            throw new Error("No user logged in")
          }

          const updatedUser: UserProfile = {
            ...currentUser,
            avatar: avatarUrl,
          }

          // Update in localStorage
          const existingUsers = JSON.parse(localStorage.getItem("registered-users") || "[]")
          const userIndex = existingUsers.findIndex((u: any) => u.id === currentUser.id)
          if (userIndex !== -1) {
            existingUsers[userIndex] = { ...existingUsers[userIndex], ...updatedUser }
            localStorage.setItem("registered-users", JSON.stringify(existingUsers))
          }

          set({
            user: updatedUser,
            isLoading: false,
            error: null,
          })

          return { success: true, avatarUrl, message: "Avatar updated successfully!" }
        } catch (error) {
          const message = error instanceof Error ? error.message : "Upload failed"
          set({ error: message, isLoading: false })
          return { success: false, message }
        }
      },

      clearError: () => {
        set({ error: null })
      },
    }),
    {
      name: "whatsapp-auth",
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
    },
  ),
)
