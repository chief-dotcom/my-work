import { create } from "zustand"

export interface CallParticipant {
  id: string
  name: string
  avatar: string
  online: boolean
}

export interface Call {
  id: string
  participant: CallParticipant
  type: "voice" | "video"
  status: "incoming" | "outgoing" | "active" | "ended"
  startTime: Date
  endTime?: Date
  duration?: number
}

export interface CallHistoryItem {
  id: string
  participant: CallParticipant
  type: "voice" | "video"
  direction: "incoming" | "outgoing" | "missed"
  timestamp: Date
  duration?: number
}

interface CallState {
  currentCall: Call | null
  callHistory: CallHistoryItem[]
  isCallModalOpen: boolean

  // Actions
  startCall: (participant: CallParticipant, type: "voice" | "video") => void
  receiveCall: (participant: CallParticipant, type: "voice" | "video") => void
  answerCall: () => void
  endCall: () => void
  rejectCall: () => void
  toggleMute: () => void
  toggleVideo: () => void
  addToHistory: (call: Omit<CallHistoryItem, "id">) => void
}

// Mock call history
const mockCallHistory: CallHistoryItem[] = [
  {
    id: "1",
    participant: {
      id: "1",
      name: "John Doe",
      avatar: "/placeholder.svg?height=40&width=40",
      online: true,
    },
    type: "video",
    direction: "outgoing",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    duration: 1245, // 20 minutes 45 seconds
  },
  {
    id: "2",
    participant: {
      id: "2",
      name: "Jane Smith",
      avatar: "/placeholder.svg?height=40&width=40",
      online: false,
    },
    type: "voice",
    direction: "incoming",
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
    duration: 892, // 14 minutes 52 seconds
  },
  {
    id: "3",
    participant: {
      id: "3",
      name: "Alice Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      online: true,
    },
    type: "voice",
    direction: "missed",
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
  },
  {
    id: "4",
    participant: {
      id: "1",
      name: "John Doe",
      avatar: "/placeholder.svg?height=40&width=40",
      online: true,
    },
    type: "video",
    direction: "outgoing",
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    duration: 2156, // 35 minutes 56 seconds
  },
]

export const useCallStore = create<CallState>((set, get) => ({
  currentCall: null,
  callHistory: mockCallHistory,
  isCallModalOpen: false,

  startCall: (participant: CallParticipant, type: "voice" | "video") => {
    const call: Call = {
      id: Date.now().toString(),
      participant,
      type,
      status: "outgoing",
      startTime: new Date(),
    }

    set({ currentCall: call, isCallModalOpen: true })

    // Simulate call connection
    setTimeout(() => {
      set((state) => ({
        currentCall: state.currentCall ? { ...state.currentCall, status: "active" } : null,
      }))
    }, 3000)
  },

  receiveCall: (participant: CallParticipant, type: "voice" | "video") => {
    const call: Call = {
      id: Date.now().toString(),
      participant,
      type,
      status: "incoming",
      startTime: new Date(),
    }

    set({ currentCall: call, isCallModalOpen: true })
  },

  answerCall: () => {
    set((state) => ({
      currentCall: state.currentCall ? { ...state.currentCall, status: "active" } : null,
    }))
  },

  endCall: () => {
    const { currentCall } = get()
    if (currentCall) {
      const endTime = new Date()
      const duration = Math.floor((endTime.getTime() - currentCall.startTime.getTime()) / 1000)

      // Add to history
      const historyItem: CallHistoryItem = {
        id: Date.now().toString(),
        participant: currentCall.participant,
        type: currentCall.type,
        direction: currentCall.status === "incoming" ? "incoming" : "outgoing",
        timestamp: currentCall.startTime,
        duration: currentCall.status === "active" ? duration : undefined,
      }

      set((state) => ({
        currentCall: null,
        isCallModalOpen: false,
        callHistory: [historyItem, ...state.callHistory],
      }))
    }
  },

  rejectCall: () => {
    const { currentCall } = get()
    if (currentCall) {
      // Add to history as missed
      const historyItem: CallHistoryItem = {
        id: Date.now().toString(),
        participant: currentCall.participant,
        type: currentCall.type,
        direction: "missed",
        timestamp: currentCall.startTime,
      }

      set((state) => ({
        currentCall: null,
        isCallModalOpen: false,
        callHistory: [historyItem, ...state.callHistory],
      }))
    }
  },

  toggleMute: () => {
    // Implementation for mute/unmute
  },

  toggleVideo: () => {
    // Implementation for video on/off
  },

  addToHistory: (call: Omit<CallHistoryItem, "id">) => {
    const historyItem: CallHistoryItem = {
      ...call,
      id: Date.now().toString(),
    }

    set((state) => ({
      callHistory: [historyItem, ...state.callHistory],
    }))
  },
}))
