"use client"

import { useState, useEffect, useRef } from "react"
import { Mic, Square, Send, X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface VoiceRecorderProps {
  onSendVoice: (audioBlob: Blob, duration: number) => void
  onCancel: () => void
}

export function VoiceRecorder({ onSendVoice, onCancel }: VoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [duration, setDuration] = useState(0)
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])

  useEffect(() => {
    startRecording()
    return () => {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
        mediaRecorderRef.current.stop()
      }
    }
  }, [])

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isRecording) {
      interval = setInterval(() => {
        setDuration((prev) => prev + 1)
      }, 1000)
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRecording])

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      chunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" })
        setAudioBlob(blob)
        stream.getTracks().forEach((track) => track.stop())
      }

      mediaRecorder.start()
      setIsRecording(true)
    } catch (error) {
      console.error("Error accessing microphone:", error)
      onCancel()
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
    }
  }

  const handleSend = () => {
    if (audioBlob) {
      onSendVoice(audioBlob, duration)
    }
  }

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  return (
    <div className="flex items-center gap-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
        <span className="text-sm font-medium text-red-600 dark:text-red-400">{formatDuration(duration)}</span>
      </div>

      <div className="flex-1 flex items-center justify-center">
        <div className="flex items-center gap-2">
          <Mic className="w-4 h-4 text-red-600 dark:text-red-400" />
          <span className="text-sm text-red-600 dark:text-red-400">Recording...</span>
        </div>
      </div>

      <div className="flex gap-2">
        <Button variant="ghost" size="icon" className="text-gray-600 dark:text-gray-400" onClick={onCancel}>
          <X className="w-4 h-4" />
        </Button>

        {isRecording ? (
          <Button variant="ghost" size="icon" className="text-red-600 dark:text-red-400" onClick={stopRecording}>
            <Square className="w-4 h-4" />
          </Button>
        ) : (
          <Button
            className="bg-[#00a884] hover:bg-[#008f72] text-white rounded-full w-10 h-10 p-0"
            onClick={handleSend}
            disabled={!audioBlob}
          >
            <Send className="w-4 h-4" />
          </Button>
        )}
      </div>
    </div>
  )
}
