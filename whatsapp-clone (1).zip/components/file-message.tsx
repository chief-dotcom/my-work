"use client"

import { Download, Play, Pause, FileText } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import type { MessageType } from "@/lib/socket"

interface FileMessageProps {
  file: {
    name: string
    size: number
    type: string
    url: string
  }
  type: MessageType
}

export function FileMessage({ file, type }: FileMessageProps) {
  const [isPlaying, setIsPlaying] = useState(false)

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const handleDownload = () => {
    const a = document.createElement("a")
    a.href = file.url
    a.download = file.name
    a.click()
  }

  if (type === "image") {
    return (
      <div className="max-w-xs">
        <img src={file.url || "/placeholder.svg"} alt={file.name} className="rounded-lg max-w-full h-auto" />
        <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
          <span>{file.name}</span>
          <Button variant="ghost" size="icon" className="w-6 h-6" onClick={handleDownload}>
            <Download className="w-3 h-3" />
          </Button>
        </div>
      </div>
    )
  }

  if (type === "video") {
    return (
      <div className="max-w-xs">
        <video controls className="rounded-lg max-w-full h-auto">
          <source src={file.url} type={file.type} />
          Your browser does not support the video tag.
        </video>
        <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
          <span>{file.name}</span>
          <span>{formatFileSize(file.size)}</span>
        </div>
      </div>
    )
  }

  if (type === "audio") {
    return (
      <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg max-w-xs">
        <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => setIsPlaying(!isPlaying)}>
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </Button>
        <div className="flex-1">
          <div className="text-sm font-medium">{file.name}</div>
          <div className="text-xs text-gray-500">{formatFileSize(file.size)}</div>
        </div>
        <Button variant="ghost" size="icon" className="w-6 h-6" onClick={handleDownload}>
          <Download className="w-3 h-3" />
        </Button>
      </div>
    )
  }

  // Document type
  return (
    <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg max-w-xs">
      <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
        <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
      </div>
      <div className="flex-1">
        <div className="text-sm font-medium truncate">{file.name}</div>
        <div className="text-xs text-gray-500">{formatFileSize(file.size)}</div>
      </div>
      <Button variant="ghost" size="icon" className="w-6 h-6" onClick={handleDownload}>
        <Download className="w-3 h-3" />
      </Button>
    </div>
  )
}
