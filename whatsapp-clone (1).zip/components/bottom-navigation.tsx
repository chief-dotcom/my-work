"use client"

import { MessageCircle, Camera, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"

interface BottomNavigationProps {
  activeTab: "chats" | "status" | "calls"
  onTabChange: (tab: "chats" | "status" | "calls") => void
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    {
      id: "chats" as const,
      label: "Chats",
      icon: MessageCircle,
    },
    {
      id: "status" as const,
      label: "Status",
      icon: Camera,
    },
    {
      id: "calls" as const,
      label: "Calls",
      icon: Phone,
    },
  ]

  return (
    <div className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-4 py-2 md:hidden">
      <div className="flex justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const isActive = activeTab === tab.id

          return (
            <Button
              key={tab.id}
              variant="ghost"
              className={`flex flex-col items-center gap-1 h-auto py-2 px-4 ${
                isActive ? "text-[#00a884] bg-[#00a884]/10" : "text-gray-600 dark:text-gray-400"
              }`}
              onClick={() => onTabChange(tab.id)}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{tab.label}</span>
            </Button>
          )
        })}
      </div>
    </div>
  )
}
