"use client"

import { useState } from "react"
import { X, Search, Phone, Video, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useSocketStore } from "@/lib/socket"
import { useCallStore } from "@/lib/call-store"
import { BackButton } from "@/components/back-button"
import { useBackButton } from "@/hooks/use-navigation"

interface ContactListModalProps {
  isOpen: boolean
  onClose: () => void
}

export function ContactListModal({ isOpen, onClose }: ContactListModalProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const { contacts, searchContacts } = useSocketStore()
  const { startCall } = useCallStore()

  // Handle back button/escape key
  useBackButton(isOpen ? onClose : undefined)

  if (!isOpen) return null

  const filteredContacts = searchQuery.trim() ? searchContacts(searchQuery) : contacts

  const handleStartChat = (contactId: string) => {
    // Implementation for starting a chat
    console.log("Start chat with:", contactId)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg max-w-md w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-[#00a884] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BackButton onBack={onClose} className="text-white hover:bg-white/20" variant="ghost" />
            <h2 className="font-medium">Contacts</h2>
          </div>
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Search */}
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              type="text"
              placeholder="Search contacts"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Contact List */}
        <ScrollArea className="flex-1 max-h-96">
          <div className="p-4">
            {filteredContacts.length > 0 ? (
              <div className="space-y-2">
                {filteredContacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg"
                  >
                    <div className="relative">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                        <AvatarFallback>
                          {contact.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      {contact.online && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white dark:border-gray-800"></div>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900 dark:text-white">{contact.name}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        {contact.online ? "Online" : contact.lastSeen || "Offline"}
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-gray-600 dark:text-gray-400 hover:text-[#00a884]"
                        onClick={() => handleStartChat(contact.id)}
                      >
                        <MessageCircle className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-gray-600 dark:text-gray-400 hover:text-[#00a884]"
                        onClick={() =>
                          startCall(
                            {
                              id: contact.id,
                              name: contact.name,
                              avatar: contact.avatar || "/placeholder.svg",
                              online: contact.online || false,
                            },
                            "voice",
                          )
                        }
                      >
                        <Phone className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-gray-600 dark:text-gray-400 hover:text-[#00a884]"
                        onClick={() =>
                          startCall(
                            {
                              id: contact.id,
                              name: contact.name,
                              avatar: contact.avatar || "/placeholder.svg",
                              online: contact.online || false,
                            },
                            "video",
                          )
                        }
                      >
                        <Video className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                  <Search className="w-8 h-8" />
                </div>
                <p className="font-medium">No contacts found</p>
                <p className="text-sm">Try a different search term</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  )
}
