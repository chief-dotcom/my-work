"use client"

import { Plus, MoreHorizontal } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

const mockStatuses = [
  {
    id: "my-status",
    name: "My Status",
    avatar: "/placeholder.svg?height=40&width=40",
    time: "Tap to add status update",
    isOwn: true,
    hasUpdate: false,
  },
  {
    id: "1",
    name: "John Doe",
    avatar: "/placeholder.svg?height=40&width=40",
    time: "2 minutes ago",
    hasUpdate: true,
    viewed: false,
  },
  {
    id: "2",
    name: "Jane Smith",
    avatar: "/placeholder.svg?height=40&width=40",
    time: "1 hour ago",
    hasUpdate: true,
    viewed: true,
  },
  {
    id: "3",
    name: "Alice Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    time: "3 hours ago",
    hasUpdate: true,
    viewed: false,
  },
]

export function StatusList() {
  return (
    <div className="w-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
      {/* Header */}
      <div className="bg-[#00a884] text-white p-4 flex items-center justify-between">
        <h2 className="font-medium text-lg">Status</h2>
        <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
          <MoreHorizontal className="w-5 h-5" />
        </Button>
      </div>

      {/* Status List */}
      <ScrollArea className="flex-1">
        <div className="p-3">
          <div className="space-y-1">
            {mockStatuses.map((status) => (
              <div
                key={status.id}
                className="flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer rounded-lg"
              >
                <div className="relative">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={status.avatar || "/placeholder.svg"} alt={status.name} />
                    <AvatarFallback>
                      {status.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  {status.isOwn && (
                    <div className="absolute bottom-0 right-0 w-6 h-6 bg-[#00a884] rounded-full flex items-center justify-center border-2 border-white dark:border-gray-800">
                      <Plus className="w-3 h-3 text-white" />
                    </div>
                  )}
                  {status.hasUpdate && !status.isOwn && (
                    <div
                      className={`absolute -inset-1 rounded-full border-2 ${
                        status.viewed ? "border-gray-300 dark:border-gray-600" : "border-[#00a884]"
                      }`}
                    />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-gray-900 dark:text-white truncate">{status.name}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300 truncate">{status.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </ScrollArea>
    </div>
  )
}
