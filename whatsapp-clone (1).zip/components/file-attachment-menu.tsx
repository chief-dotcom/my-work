"use client"

import { useState } from "react"
import { Paperclip, ImageIcon, Video, FileText, Mic } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { MessageType } from "@/lib/socket"

interface FileAttachmentMenuProps {
  onFileSelect: (file: File, type: MessageType) => void
}

export function FileAttachmentMenu({ onFileSelect }: FileAttachmentMenuProps) {
  const [isOpen, setIsOpen] = useState(false)

  const handleFileSelect = (type: MessageType, accept: string) => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = accept
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) {
        onFileSelect(file, type)
      }
    }
    input.click()
    setIsOpen(false)
  }

  const attachmentOptions = [
    {
      type: "image" as MessageType,
      icon: ImageIcon,
      label: "Photo",
      accept: "image/*",
      color: "text-purple-600",
    },
    {
      type: "video" as MessageType,
      icon: Video,
      label: "Video",
      accept: "video/*",
      color: "text-red-600",
    },
    {
      type: "document" as MessageType,
      icon: FileText,
      label: "Document",
      accept: ".pdf,.doc,.docx,.txt",
      color: "text-blue-600",
    },
    {
      type: "audio" as MessageType,
      icon: Mic,
      label: "Audio",
      accept: "audio/*",
      color: "text-green-600",
    },
  ]

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        className="text-gray-600 dark:text-gray-400"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Paperclip className="w-5 h-5" />
      </Button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          <div className="absolute bottom-full left-0 mb-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 p-2 z-50">
            <div className="grid grid-cols-2 gap-2 w-48">
              {attachmentOptions.map((option) => {
                const Icon = option.icon
                return (
                  <button
                    key={option.type}
                    className="flex flex-col items-center gap-2 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    onClick={() => handleFileSelect(option.type, option.accept)}
                  >
                    <Icon className={`w-6 h-6 ${option.color}`} />
                    <span className="text-xs text-gray-700 dark:text-gray-300">{option.label}</span>
                  </button>
                )
              })}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
