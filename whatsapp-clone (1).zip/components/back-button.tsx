"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface BackButtonProps {
  onBack: () => void
  className?: string
  variant?: "default" | "ghost" | "outline"
  size?: "default" | "sm" | "lg" | "icon"
}

export function BackButton({ onBack, className, variant = "ghost", size = "icon" }: BackButtonProps) {
  return (
    <Button variant={variant} size={size} onClick={onBack} className={cn("", className)} aria-label="Go back">
      <ArrowLeft className="w-5 h-5" />
    </Button>
  )
}
