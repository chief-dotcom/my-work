"use client"

interface QuickEmojiBarProps {
  onEmojiSelect: (emoji: string) => void
}

const quickEmojis = ["👍", "❤️", "😂", "😮", "😢", "😡"]

export function QuickEmojiBar({ onEmojiSelect }: QuickEmojiBarProps) {
  return (
    <div className="flex gap-2 mb-3 pb-3 border-b border-gray-200 dark:border-gray-700">
      {quickEmojis.map((emoji, index) => (
        <button
          key={index}
          className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-lg transition-colors"
          onClick={() => onEmojiSelect(emoji)}
        >
          {emoji}
        </button>
      ))}
    </div>
  )
}
