"use client"

import { Phone, PhoneOff, Mic, MicOff, Video, VideoOff } from "lucide-react"
import { useState, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { useCallStore } from "@/lib/call-store"

interface CallModalProps {
  isOpen: boolean
  onClose: () => void
}

export function CallModal({ isOpen, onClose }: CallModalProps) {
  const { currentCall, answerCall, endCall, rejectCall } = useCallStore()
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoOff, setIsVideoOff] = useState(false)
  const [callDuration, setCallDuration] = useState(0)

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (currentCall?.status === "active") {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1)
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [currentCall?.status])

  useEffect(() => {
    if (!currentCall) {
      setCallDuration(0)
      setIsMuted(false)
      setIsVideoOff(false)
      onClose()
    }
  }, [currentCall, onClose])

  if (!isOpen || !currentCall) return null

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  const getStatusText = () => {
    switch (currentCall.status) {
      case "incoming":
        return "Incoming call..."
      case "outgoing":
        return "Calling..."
      case "active":
        return formatDuration(callDuration)
      default:
        return ""
    }
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* Call Info */}
      <div className="flex-1 flex flex-col items-center justify-center text-white p-8">
        <Avatar className="w-32 h-32 mb-6">
          <AvatarImage src={currentCall.participant.avatar || "/placeholder.svg"} alt={currentCall.participant.name} />
          <AvatarFallback className="text-4xl">
            {currentCall.participant.name
              .split(" ")
              .map((n) => n[0])
              .join("")}
          </AvatarFallback>
        </Avatar>

        <h2 className="text-2xl font-medium mb-2">{currentCall.participant.name}</h2>
        <p className="text-lg text-gray-300 mb-4">{getStatusText()}</p>

        {currentCall.type === "video" && (
          <div className="text-sm text-gray-400 flex items-center gap-2">
            <Video className="w-4 h-4" />
            Video call
          </div>
        )}
      </div>

      {/* Call Controls */}
      <div className="p-8">
        <div className="flex justify-center items-center gap-6">
          {currentCall.status === "incoming" ? (
            <>
              {/* Incoming call controls */}
              <Button
                size="lg"
                className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600"
                onClick={() => {
                  rejectCall()
                  onClose()
                }}
              >
                <PhoneOff className="w-6 h-6" />
              </Button>

              <Button size="lg" className="w-16 h-16 rounded-full bg-green-500 hover:bg-green-600" onClick={answerCall}>
                <Phone className="w-6 h-6" />
              </Button>
            </>
          ) : (
            <>
              {/* Active/Outgoing call controls */}
              <Button
                variant={isMuted ? "default" : "secondary"}
                size="lg"
                className="w-14 h-14 rounded-full"
                onClick={() => setIsMuted(!isMuted)}
              >
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </Button>

              {currentCall.type === "video" && (
                <Button
                  variant={isVideoOff ? "default" : "secondary"}
                  size="lg"
                  className="w-14 h-14 rounded-full"
                  onClick={() => setIsVideoOff(!isVideoOff)}
                >
                  {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
                </Button>
              )}

              <Button
                size="lg"
                className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600"
                onClick={() => {
                  endCall()
                  onClose()
                }}
              >
                <PhoneOff className="w-6 h-6" />
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
