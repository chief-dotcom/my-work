"use client"

import { useState } from "react"
import { Menu, Settings, Users, Archive, Star, Info, LogOut, UserPlus, Users2, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useBackButton } from "@/hooks/use-navigation"
import { useAuthStore } from "@/lib/auth-store"

interface HamburgerMenuProps {
  onNewGroup?: () => void
  onAddContact?: () => void
  onViewContacts?: () => void
  onViewProfile?: () => void
}

export function HamburgerMenu({ onNewGroup, onAddContact, onViewContacts, onViewProfile }: HamburgerMenuProps) {
  const [isOpen, setIsOpen] = useState(false)
  const { user, logout } = useAuthStore()

  // Handle back button to close menu
  useBackButton(isOpen ? () => setIsOpen(false) : undefined)

  const menuItems = [
    {
      icon: Users,
      label: "New Group",
      action: () => {
        onNewGroup?.()
        setIsOpen(false)
      },
    },
    {
      icon: UserPlus,
      label: "Add Contact",
      action: () => {
        onAddContact?.()
        setIsOpen(false)
      },
    },
    {
      icon: Users2,
      label: "Contacts",
      action: () => {
        onViewContacts?.()
        setIsOpen(false)
      },
    },
    {
      icon: Star,
      label: "Starred Messages",
      action: () => setIsOpen(false),
    },
    {
      icon: Archive,
      label: "Archived Chats",
      action: () => setIsOpen(false),
    },
    {
      icon: Settings,
      label: "Settings",
      action: () => setIsOpen(false),
    },
    {
      icon: Info,
      label: "Help",
      action: () => setIsOpen(false),
    },
  ]

  const handleLogout = () => {
    logout()
    setIsOpen(false)
  }

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        className="text-white hover:bg-white/20"
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Menu"
      >
        <Menu className="w-5 h-5" />
      </Button>

      {isOpen && (
        <>
          {/* Backdrop */}
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} aria-hidden="true" />

          {/* Menu */}
          <div className="absolute top-full right-0 mt-2 w-64 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-50 overflow-hidden">
            {/* Profile Section */}
            <div className="p-4 border-b border-gray-100 dark:border-gray-700">
              <div
                className="flex items-center gap-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 p-2 rounded-lg -m-2"
                onClick={() => {
                  onViewProfile?.()
                  setIsOpen(false)
                }}
              >
                <Avatar className="w-12 h-12">
                  <AvatarImage src={user?.avatar || "/placeholder.svg"} alt="Profile" />
                  <AvatarFallback>
                    {user?.name
                      ?.split(" ")
                      .map((n) => n[0])
                      .join("") || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="font-medium text-gray-900 dark:text-white">{user?.name || "User"}</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">{user?.bio || "Available"}</div>
                </div>
                <User className="w-4 h-4 text-gray-400" />
              </div>
            </div>

            {/* Menu Items */}
            <div className="py-2">
              {menuItems.map((item, index) => {
                const Icon = item.icon
                return (
                  <button
                    key={index}
                    className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                    onClick={item.action}
                  >
                    <Icon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                    <span className="text-gray-700 dark:text-gray-300">{item.label}</span>
                  </button>
                )
              })}
            </div>

            {/* Logout */}
            <div className="border-t border-gray-100 dark:border-gray-700">
              <button
                className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-red-600 dark:text-red-400"
                onClick={handleLogout}
              >
                <LogOut className="w-5 h-5" />
                <span>Log Out</span>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
