"use client"

import { useState } from "react"
import { X, Search, UserPlus, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useSocketStore } from "@/lib/socket"
import { BackButton } from "@/components/back-button"
import { useBackButton } from "@/hooks/use-navigation"

interface AddContactModalProps {
  isOpen: boolean
  onClose: () => void
}

export function AddContactModal({ isOpen, onClose }: AddContactModalProps) {
  const [activeTab, setActiveTab] = useState<"phone" | "search">("phone")
  const [phoneNumber, setPhoneNumber] = useState("")
  const [contactName, setContactName] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  const { addContact, searchContacts } = useSocketStore()

  // Handle back button/escape key
  useBackButton(isOpen ? onClose : undefined)

  if (!isOpen) return null

  const formatPhoneNumber = (value: string) => {
    const digits = value.replace(/\D/g, "")
    if (digits.length >= 10) {
      return `+1 (${digits.slice(-10, -7)}) ${digits.slice(-7, -4)}-${digits.slice(-4)}`
    }
    return digits.length > 0 ? `+${digits}` : ""
  }

  const handlePhoneChange = (value: string) => {
    const formatted = formatPhoneNumber(value)
    setPhoneNumber(formatted)
  }

  const handleAddByPhone = async () => {
    if (!phoneNumber.trim()) {
      setMessage({ type: "error", text: "Please enter a phone number" })
      return
    }

    setIsLoading(true)
    setMessage(null)

    try {
      const result = await addContact({
        name: contactName.trim() || phoneNumber,
        phone: phoneNumber,
      })

      if (result.success) {
        setMessage({ type: "success", text: result.message })
        setPhoneNumber("")
        setContactName("")
        setTimeout(() => {
          setMessage(null)
          onClose()
        }, 2000)
      } else {
        setMessage({ type: "error", text: result.message })
      }
    } catch (error) {
      setMessage({ type: "error", text: "Failed to add contact" })
    } finally {
      setIsLoading(false)
    }
  }

  const searchResults = searchQuery.trim() ? searchContacts(searchQuery) : []

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg max-w-md w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-[#00a884] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BackButton onBack={onClose} className="text-white hover:bg-white/20" variant="ghost" />
            <h2 className="font-medium">Add Contact</h2>
          </div>
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 dark:border-gray-700">
          <button
            className={`flex-1 py-3 px-4 text-sm font-medium ${
              activeTab === "phone" ? "text-[#00a884] border-b-2 border-[#00a884]" : "text-gray-600 dark:text-gray-400"
            }`}
            onClick={() => setActiveTab("phone")}
          >
            Add by Phone
          </button>
          <button
            className={`flex-1 py-3 px-4 text-sm font-medium ${
              activeTab === "search" ? "text-[#00a884] border-b-2 border-[#00a884]" : "text-gray-600 dark:text-gray-400"
            }`}
            onClick={() => setActiveTab("search")}
          >
            Search Users
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Message Display */}
          {message && (
            <div
              className={`mb-4 p-3 rounded-lg text-sm ${
                message.type === "success"
                  ? "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 border border-green-200 dark:border-green-800"
                  : "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-800"
              }`}
            >
              {message.text}
            </div>
          )}

          {activeTab === "phone" ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Phone Number *
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={phoneNumber}
                    onChange={(e) => handlePhoneChange(e.target.value)}
                    className="pl-10"
                    disabled={isLoading}
                    maxLength={20}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Contact Name (Optional)
                </label>
                <Input
                  type="text"
                  placeholder="Enter contact name"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  disabled={isLoading}
                  maxLength={50}
                />
              </div>

              <Button
                onClick={handleAddByPhone}
                className="w-full bg-[#00a884] hover:bg-[#008f72] text-white"
                disabled={isLoading || !phoneNumber.trim()}
              >
                {isLoading ? "Adding..." : "Add Contact"}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  type="text"
                  placeholder="Search by name or username"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              {searchQuery.trim() && (
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {searchResults.length > 0 ? (
                    searchResults.map((contact) => (
                      <div
                        key={contact.id}
                        className="flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg cursor-pointer"
                      >
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                          <AvatarFallback>
                            {contact.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="font-medium text-gray-900 dark:text-white">{contact.name}</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">{contact.phone}</div>
                        </div>
                        <Button size="sm" className="bg-[#00a884] hover:bg-[#008f72] text-white">
                          <UserPlus className="w-4 h-4" />
                        </Button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                      <UserPlus className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No users found</p>
                      <p className="text-sm">Try a different search term</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
