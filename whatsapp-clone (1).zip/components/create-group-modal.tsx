"use client"

import { useState } from "react"
import { X, Users, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useSocketStore } from "@/lib/socket"
import { BackButton } from "@/components/back-button"
import { useBackButton } from "@/hooks/use-navigation"

interface CreateGroupModalProps {
  isOpen: boolean
  onClose: () => void
}

export function CreateGroupModal({ isOpen, onClose }: CreateGroupModalProps) {
  const [groupName, setGroupName] = useState("")
  const [selectedContacts, setSelectedContacts] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  const { contacts, createGroup } = useSocketStore()

  // Handle back button/escape key
  useBackButton(isOpen ? onClose : undefined)

  if (!isOpen) return null

  const handleContactToggle = (contactId: string) => {
    setSelectedContacts((prev) =>
      prev.includes(contactId) ? prev.filter((id) => id !== contactId) : [...prev, contactId],
    )
  }

  const handleCreateGroup = async () => {
    if (!groupName.trim()) {
      setMessage({ type: "error", text: "Please enter a group name" })
      return
    }

    if (selectedContacts.length === 0) {
      setMessage({ type: "error", text: "Please select at least one contact" })
      return
    }

    setIsLoading(true)
    setMessage(null)

    try {
      const result = await createGroup(groupName.trim(), selectedContacts)

      if (result.success) {
        setMessage({ type: "success", text: result.message })
        setGroupName("")
        setSelectedContacts([])
        setTimeout(() => {
          setMessage(null)
          onClose()
        }, 2000)
      } else {
        setMessage({ type: "error", text: result.message })
      }
    } catch (error) {
      setMessage({ type: "error", text: "Failed to create group" })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg max-w-md w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-[#00a884] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BackButton onBack={onClose} className="text-white hover:bg-white/20" variant="ghost" />
            <h2 className="font-medium">New Group</h2>
          </div>
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Message Display */}
          {message && (
            <div
              className={`mb-4 p-3 rounded-lg text-sm ${
                message.type === "success"
                  ? "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 border border-green-200 dark:border-green-800"
                  : "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-800"
              }`}
            >
              {message.text}
            </div>
          )}

          {/* Group Name */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Group Name *</label>
            <div className="relative">
              <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="text"
                placeholder="Enter group name"
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                className="pl-10"
                disabled={isLoading}
                maxLength={50}
              />
            </div>
          </div>

          {/* Selected Contacts Count */}
          {selectedContacts.length > 0 && (
            <div className="mb-4 text-sm text-gray-600 dark:text-gray-400">
              {selectedContacts.length} contact{selectedContacts.length !== 1 ? "s" : ""} selected
            </div>
          )}

          {/* Contact List */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Select Contacts</label>
            <ScrollArea className="max-h-60 border border-gray-200 dark:border-gray-700 rounded-lg">
              <div className="p-2">
                {contacts.map((contact) => (
                  <div
                    key={contact.id}
                    className={`flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg cursor-pointer ${
                      selectedContacts.includes(contact.id) ? "bg-[#00a884]/10" : ""
                    }`}
                    onClick={() => handleContactToggle(contact.id)}
                  >
                    <div className="relative">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                        <AvatarFallback>
                          {contact.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      {selectedContacts.includes(contact.id) && (
                        <div className="absolute -top-1 -right-1 w-5 h-5 bg-[#00a884] rounded-full flex items-center justify-center">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900 dark:text-white">{contact.name}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">{contact.phone}</div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Create Button */}
          <Button
            onClick={handleCreateGroup}
            className="w-full bg-[#00a884] hover:bg-[#008f72] text-white"
            disabled={isLoading || !groupName.trim() || selectedContacts.length === 0}
          >
            {isLoading ? "Creating Group..." : "Create Group"}
          </Button>
        </div>
      </div>
    </div>
  )
}
