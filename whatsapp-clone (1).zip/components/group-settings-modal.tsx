"use client"
import { X, Users, Crown, UserMinus, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { BackButton } from "@/components/back-button"
import { useBackButton } from "@/hooks/use-navigation"
import type { Chat } from "@/lib/socket"

interface GroupSettingsModalProps {
  isOpen: boolean
  onClose: () => void
  group: Chat | null
}

export function GroupSettingsModal({ isOpen, onClose, group }: GroupSettingsModalProps) {
  // Handle back button/escape key
  useBackButton(isOpen ? onClose : undefined)

  if (!isOpen || !group || !group.isGroup) return null

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg max-w-md w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-[#00a884] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BackButton onBack={onClose} className="text-white hover:bg-white/20" variant="ghost" />
            <h2 className="font-medium">Group Info</h2>
          </div>
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Group Info */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16">
              <AvatarImage src={group.avatar || "/placeholder.svg"} alt={group.name} />
              <AvatarFallback className="text-xl">
                <Users className="w-8 h-8" />
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="text-xl font-medium text-gray-900 dark:text-white">{group.name}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Group • {group.participants?.length || 0} participants
              </p>
            </div>
          </div>
        </div>

        {/* Participants */}
        <div className="p-6">
          <h4 className="font-medium text-gray-900 dark:text-white mb-4">
            {group.participants?.length || 0} Participants
          </h4>
          <ScrollArea className="max-h-60">
            <div className="space-y-2">
              {group.participants?.map((participant) => (
                <div
                  key={participant.id}
                  className="flex items-center gap-3 p-2 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg"
                >
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={participant.avatar || "/placeholder.svg"} alt={participant.name} />
                    <AvatarFallback>
                      {participant.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="font-medium text-gray-900 dark:text-white flex items-center gap-2">
                      {participant.name}
                      {participant.role === "admin" && <Crown className="w-4 h-4 text-yellow-500" />}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {participant.role === "admin" ? "Group Admin" : "Member"}
                    </div>
                  </div>
                  {participant.role !== "admin" && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
                    >
                      <UserMinus className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Actions */}
        <div className="p-6 border-t border-gray-200 dark:border-gray-700">
          <div className="space-y-2">
            <Button variant="outline" className="w-full justify-start" onClick={onClose}>
              <Settings className="w-4 h-4 mr-2" />
              Group Settings
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start text-red-600 hover:text-red-700"
              onClick={onClose}
            >
              <UserMinus className="w-4 h-4 mr-2" />
              Leave Group
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
