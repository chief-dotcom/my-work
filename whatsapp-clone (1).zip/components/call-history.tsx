"use client"

import { Phone, Video, PhoneIncoming, PhoneOutgoing, PhoneMissed } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useCallStore } from "@/lib/call-store"

export function CallHistory() {
  const { callHistory, startCall } = useCallStore()

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  const formatTime = (date: Date) => {
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } else if (diffInHours < 48) {
      return "Yesterday"
    } else {
      return date.toLocaleDateString()
    }
  }

  const getCallIcon = (direction: string, type: string) => {
    if (direction === "missed") {
      return <PhoneMissed className="w-4 h-4 text-red-500" />
    } else if (direction === "incoming") {
      return <PhoneIncoming className="w-4 h-4 text-green-500" />
    } else {
      return <PhoneOutgoing className="w-4 h-4 text-gray-500" />
    }
  }

  return (
    <div className="w-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
      {/* Header */}
      <div className="bg-[#00a884] text-white p-4">
        <h2 className="font-medium text-lg">Calls</h2>
      </div>

      {/* Call History */}
      <ScrollArea className="flex-1">
        <div className="p-3">
          <div className="space-y-1">
            {callHistory.map((call) => (
              <div
                key={call.id}
                className="flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg"
              >
                <Avatar className="w-12 h-12">
                  <AvatarImage src={call.participant.avatar || "/placeholder.svg"} alt={call.participant.name} />
                  <AvatarFallback>
                    {call.participant.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-gray-900 dark:text-white truncate">{call.participant.name}</h3>
                  <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                    {getCallIcon(call.direction, call.type)}
                    <span>{formatTime(call.timestamp)}</span>
                    {call.duration && (
                      <>
                        <span>•</span>
                        <span>{formatDuration(call.duration)}</span>
                      </>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => startCall(call.participant, "voice")}
                    className="text-gray-600 dark:text-gray-400 hover:text-[#00a884]"
                  >
                    <Phone className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => startCall(call.participant, "video")}
                    className="text-gray-600 dark:text-gray-400 hover:text-[#00a884]"
                  >
                    <Video className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </ScrollArea>
    </div>
  )
}
