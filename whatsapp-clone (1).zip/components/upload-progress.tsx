"use client"

import { X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface UploadProgressProps {
  fileName: string
  progress: number
  onCancel?: () => void
}

export function UploadProgress({ fileName, progress, onCancel }: UploadProgressProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-3 shadow-lg border border-gray-200 dark:border-gray-700 mb-2">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-gray-900 dark:text-white truncate">{fileName}</span>
        {onCancel && (
          <Button variant="ghost" size="icon" className="w-6 h-6" onClick={onCancel}>
            <X className="w-3 h-3" />
          </Button>
        )}
      </div>
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
        <div className="bg-[#00a884] h-2 rounded-full transition-all duration-300" style={{ width: `${progress}%` }} />
      </div>
      <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">{progress}%</div>
    </div>
  )
}
