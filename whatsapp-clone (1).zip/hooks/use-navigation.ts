"use client"

import { create } from "zustand"
import { useEffect } from "react"

interface NavigationState {
  currentView: string
  viewHistory: string[]
  pushView: (view: string) => void
  popView: () => string | null
  setCurrentView: (view: string) => void
  canGoBack: () => boolean
}

export const useNavigationStore = create<NavigationState>((set, get) => ({
  currentView: "chats",
  viewHistory: [],

  pushView: (view: string) => {
    const { currentView, viewHistory } = get()
    set({
      currentView: view,
      viewHistory: [...viewHistory, currentView],
    })
  },

  popView: () => {
    const { viewHistory } = get()
    if (viewHistory.length > 0) {
      const previousView = viewHistory[viewHistory.length - 1]
      const newHistory = viewHistory.slice(0, -1)
      set({
        currentView: previousView,
        viewHistory: newHistory,
      })
      return previousView
    }
    return null
  },

  setCurrentView: (view: string) => {
    set({ currentView: view, viewHistory: [] })
  },

  canGoBack: () => {
    return get().viewHistory.length > 0
  },
}))

export function useBackButton(onBack?: () => boolean | void) {
  const { popView, canGoBack } = useNavigationStore()

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" || event.key === "Backspace") {
        event.preventDefault()

        // Try custom handler first
        if (onBack) {
          const handled = onBack()
          if (handled !== false) return
        }

        // Fall back to navigation store
        if (canGoBack()) {
          popView()
        }
      }
    }

    // Handle browser back button
    const handlePopState = (event: PopStateEvent) => {
      event.preventDefault()

      if (onBack) {
        const handled = onBack()
        if (handled !== false) return
      }

      if (canGoBack()) {
        popView()
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("popstate", handlePopState)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("popstate", handlePopState)
    }
  }, [onBack, popView, canGoBack])
}
