"use client"

import WhatsAppClone from "../whatsapp-clone"

export default function SyntheticV0PageForDeployment() {
  return <WhatsAppClone />
}